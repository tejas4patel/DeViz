import ScrollStoryShell from "./story/scroll_story_shell"

export default function App() {
  return <ScrollStoryShell />
}
