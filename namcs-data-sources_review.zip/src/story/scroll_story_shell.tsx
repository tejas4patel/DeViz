import { useEffect, useMemo, useRef, useState } from "react"
import { story } from "./story_data"
import SceneRenderer from "./scene_renderer"

export default function ScrollStoryShell() {
  const scenes = story.scenes
  const [activeIdx, setActiveIdx] = useState(0)

  const meta = useMemo(() => {
    return {
      storyTitle: story.title,
      storySubtitle: story.subtitle
    }
  }, [])

  const activeScene = scenes[activeIdx]

  // Wheel paging state (handles trackpads + mouse wheels)
  const lastFlipTsRef = useRef(0)
  const accumDeltaRef = useRef(0)

  const canPrev = activeIdx > 0
  const canNext = activeIdx < scenes.length - 1

  useEffect(() => {
    // Prevent the browser from scrolling the page
    const onWheel = (e: WheelEvent) => {
      // If user is trying to zoom (ctrl+wheel), do not hijack
      if (e.ctrlKey) return

      // If the scene content itself is scrollable and user is scrolling inside it,
      // let that internal scroll happen instead of flipping slides.
      const target = e.target as HTMLElement | null
      const scrollableAncestor = target?.closest?.(".slideScrollBody") as HTMLElement | null
      if (scrollableAncestor) {
        const atTop = scrollableAncestor.scrollTop <= 0
        const atBottom =
          Math.ceil(scrollableAncestor.scrollTop + scrollableAncestor.clientHeight) >=
          scrollableAncestor.scrollHeight

        // Only flip slides if the user is at the edge of the internal scroller
        if ((e.deltaY < 0 && !atTop) || (e.deltaY > 0 && !atBottom)) {
          return
        }
      }

      e.preventDefault()

      const now = Date.now()
      const cooldownMs = 450

      // Cooldown so one "gesture" maps to one slide
      if (now - lastFlipTsRef.current < cooldownMs) return

      // Accumulate delta for trackpads (many small events)
      accumDeltaRef.current += e.deltaY
      const threshold = 80

      if (Math.abs(accumDeltaRef.current) < threshold) return

      const dir = accumDeltaRef.current > 0 ? 1 : -1
      accumDeltaRef.current = 0
      lastFlipTsRef.current = now

      setActiveIdx((prev) => {
        const next = prev + dir
        if (next < 0) return 0
        if (next > scenes.length - 1) return scenes.length - 1
        return next
      })
    }

    window.addEventListener("wheel", onWheel, { passive: false })
    return () => window.removeEventListener("wheel", onWheel as EventListener)
  }, [scenes.length])

  // Optional: keyboard paging feels very "slide deck"
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown" || e.key === "PageDown" || e.key === " ") {
        e.preventDefault()
        if (canNext) setActiveIdx((v) => Math.min(scenes.length - 1, v + 1))
      }
      if (e.key === "ArrowUp" || e.key === "PageUp") {
        e.preventDefault()
        if (canPrev) setActiveIdx((v) => Math.max(0, v - 1))
      }
      if (e.key === "Home") {
        e.preventDefault()
        setActiveIdx(0)
      }
      if (e.key === "End") {
        e.preventDefault()
        setActiveIdx(scenes.length - 1)
      }
    }

    window.addEventListener("keydown", onKeyDown, { passive: false })
    return () => window.removeEventListener("keydown", onKeyDown as EventListener)
  }, [canNext, canPrev, scenes.length])

  return (
    <div className="scrollyShell">
      <header className="scrollyHeader card">
        <div style={{ fontSize: 18, fontWeight: 800 }}>{meta.storyTitle}</div>
        <div className="small" style={{ marginTop: 6 }}>
          {meta.storySubtitle}
        </div>

        <div className="slideCounter small" style={{ marginTop: 8 }}>
          Slide {activeIdx + 1} of {scenes.length}
        </div>
      </header>

      <div className="scrollyBody singleCol">
        <div className="scrollyViz card">
          <div className="sceneHeader">
            <div>
              <div style={{ fontSize: 20, fontWeight: 800 }}>{activeScene.title}</div>
              <div className="small" style={{ marginTop: 4 }}>{activeScene.subtitle}</div>
            </div>
            <div className="small">{activeScene.id}</div>
          </div>

          {/* This wrapper is what the wheel handler checks to allow internal scrolling */}
          <div className="slideScrollBody">
            <SceneRenderer scene={activeScene} />

            {activeScene.notes ? (
              <div className="small" style={{ marginTop: 12 }}>
                Notes: {activeScene.notes}
              </div>
            ) : null}
          </div>

          <div className="navBtnRow">
            <button
              className="btn"
              disabled={!canPrev}
              onClick={() => setActiveIdx((v) => Math.max(0, v - 1))}
            >
              Prev
            </button>
            <button
              className="btn"
              disabled={!canNext}
              onClick={() => setActiveIdx((v) => Math.min(scenes.length - 1, v + 1))}
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
