import ScenePlaceholder from "./scene_placeholder"

export default function Scene12LinkageRates() {
  return (
    <ScenePlaceholder
      title="Scene 12"
      description="Small multiples placeholder. Replace with age and sex linkage rate visuals and counts."
    />
  )
}
