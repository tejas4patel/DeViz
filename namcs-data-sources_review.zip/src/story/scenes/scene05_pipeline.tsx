import ScenePlaceholder from "./scene_placeholder"

export default function Scene05Pipeline() {
  return (
    <ScenePlaceholder
      title="Scene 05"
      description="Flow diagram placeholder. Replace with a sankey or node flow for recruitment, questionnaire, HL7 install, testing, submission."
    />
  )
}
