import ScenePlaceholder from "./scene_placeholder"

export default function Scene03BeforeAfter() {
  return (
    <ScenePlaceholder
      title="Scene 03"
      description="Before and after placeholder. Replace with a split panel showing pre 2021 collection and post 2021 full year EHR pipeline."
    />
  )
}
