import ScenePlaceholder from "./scene_placeholder"

export default function Scene13Limitations() {
  return (
    <ScenePlaceholder
      title="Scene 13"
      description="Limitations placeholder. Replace with an interactive checklist or radar view and a weight normalization explanation panel."
    />
  )
}
