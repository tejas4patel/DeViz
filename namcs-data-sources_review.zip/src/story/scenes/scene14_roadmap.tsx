import ScenePlaceholder from "./scene_placeholder"

export default function Scene14Roadmap() {
  return (
    <ScenePlaceholder
      title="Scene 14"
      description="Roadmap placeholder. Replace with a timeline of planned releases, dashboard modules, and future linkages."
    />
  )
}
