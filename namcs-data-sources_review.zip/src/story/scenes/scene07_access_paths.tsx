import ScenePlaceholder from "./scene_placeholder"

export default function Scene07AccessPaths() {
  return (
    <ScenePlaceholder
      title="Scene 07"
      description="Journey map placeholder. Replace with two lanes comparing public download path and RDC path."
    />
  )
}
