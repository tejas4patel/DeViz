declare module "react-scrollama";
